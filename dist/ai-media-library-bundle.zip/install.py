#!/usr/bin/env python3
import argparse, hashlib, json, os, pathlib, shutil, sys
p=argparse.ArgumentParser(description="安装 小红书爆款素材+选题工作台搭建；不覆盖已有 Skill")
p.add_argument('--check', action='store_true')
p.add_argument('--target', default=str(pathlib.Path(os.environ.get('CODEX_HOME',str(pathlib.Path.home()/'.codex')))/'skills'))
a=p.parse_args();base=pathlib.Path(__file__).resolve().parent;src=base/'ai-media-library'
manifest=json.loads((base/'MANIFEST.json').read_text(encoding='utf-8'))
actual={f.relative_to(src).as_posix() for f in src.rglob('*') if f.is_file()}
if actual!=set(manifest): sys.exit('文件清单不一致，停止安装')
for rel,digest in manifest.items():
 f=src/rel
 if f.is_symlink() or hashlib.sha256(f.read_bytes()).hexdigest()!=digest:sys.exit('文件校验失败，停止安装')
if a.check:
 print('校验通过：'+str(len(manifest))+'个文件');sys.exit(0)
dest=pathlib.Path(a.target).expanduser()/'ai-media-library'
if dest.exists():sys.exit('目标 Skill 已存在，未覆盖：'+str(dest))
dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(src,dest)
print('已安装：'+str(dest));print('重新打开一次会话后，调用 $ai-media-library。配置和真实连接测试尚需在使用时完成。')
